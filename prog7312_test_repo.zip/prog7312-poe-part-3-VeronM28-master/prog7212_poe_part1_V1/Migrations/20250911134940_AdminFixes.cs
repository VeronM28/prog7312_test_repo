﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace prog7212_poe_part1_V1.Migrations
{
    /// <inheritdoc />
    public partial class AdminFixes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
